﻿using Re.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Re.Controllers
{
    [HandleException]
    public class LoginController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Logon()
        {
            return RedirectToAction("Index", "Home");
        }
    }
}