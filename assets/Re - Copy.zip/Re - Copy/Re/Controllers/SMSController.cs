﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Re.Controllers
{
    public class SMSController : Controller
    {
        public ActionResult SendSMS()
        {
            return View();
        }
    }
}