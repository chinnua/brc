﻿using Re.Filters;
using Re.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace Re.Controllers
{
    [HandleException]
    public class FeeController : Controller
    {
        public ActionResult CollectFee()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CollectFee(int StudentId)
        {
            return RedirectToAction("StudentDetails", new { StudentId = StudentId });
        }

        [HttpGet]
        public ActionResult StudentDetails(int StudentId)
        {
            Student sd = new Student();
            sd.Id = StudentId;
            sd.StudentName = "Arul";
            sd.AdminssionNumber = "1234";
            sd.Class = "12";
            sd.Section = "B";
            sd.PickupPointId = 1;
            sd.ParentName = "A";
            sd.ParentContactNumber = "9884959058";
            return View(sd);
        }

        [HttpPost]
        public ActionResult StudentDetails(Student student)
        {
            TempData["StudentDetails"] = student;
            return RedirectToAction("FeeDetails");
        }

        [HttpGet]
        public ActionResult FeeDetails()
        {
            Student student = (Student)TempData["StudentDetails"];
            Fee feeDetails = new Fee();
            feeDetails.StudentDetails = student;
            feeDetails.Amount = 17000;
            feeDetails.FeeType = "Tr Fees";
            feeDetails.Term = 3;
            feeDetails.CollectedBy = 1;
            feeDetails.CollectedDate = System.DateTime.Now;
            return View(feeDetails);
        }

        [HttpPost]
        public ActionResult FeeDetails(Fee feeDetails)
        {
            TempData["feeDetails"] = feeDetails;
            return RedirectToAction("FeeReceipt");
        }

        [HttpGet]
        public  ActionResult FeeReceipt()
        {
            Fee feeDetails = (Fee)TempData["feeDetails"];
            return View(feeDetails);
        }
    }
}