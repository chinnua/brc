﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Re.Models
{
    public class Fee
    {
        public Student StudentDetails { get; set; }

        [Required]
        [Display(Name = "Fee Type")]
        public string FeeType { get; set; }

        [Required]
        [Display(Name = "Term")]
        public int Term { get; set; }

        [Required]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:0.00}")]
        public decimal Amount { get; set; }

        [Required]
        [Display(Name = "Collected Date")]
        public DateTime CollectedDate { get; set; }

        [Required]
        [Display(Name = "Collected By")]
        public int CollectedBy { get; set; }
    }
}