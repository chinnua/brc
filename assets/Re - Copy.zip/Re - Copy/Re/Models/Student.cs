﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Re.Models
{
    public class Student
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [Display(Name = "Student Name")]
        public string StudentName { get; set; }

        [Required]
        [Display(Name = "Admission Number")]
        public string AdminssionNumber { get; set; }

        [Required]
        public string Class { get; set; }
        public string Section { get; set; }

        [Required]
        [Display(Name = "Pickup Point")]
        public int PickupPointId { get; set; }

        [Required]
        [Display(Name = "Parent Name")]
        public string ParentName { get; set; }

        [Required]
        [Display(Name = "Parent Contact Number")]
        public string ParentContactNumber { get; set; }

        [ScaffoldColumn(false)]
        public bool IsActive { get; set; }
    }
}