﻿using System.Web;
using System.Web.Optimization;

namespace Re
{
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/themeJS").Include(
                        "~/js/lib/jquery/jquery.min.js",
                        "~/js/lib/bootstrap/js/popper.min.js",
                        "~/js/lib/bootstrap/js/bootstrap.min.js",
                        "~/js/jquery.slimscroll.js",
                        "~/js/sidebarmenu.js",
                        "~/js/lib/sticky-kit-master/dist/sticky-kit.min.js",
                        "~/js/lib/owl-carousel/owl.carousel.min.js",
                        "~/js/lib/owl-carousel/owl.carousel-init.js",
                        "~/js/scripts.js"));

            bundles.Add(new StyleBundle("~/bundles/themeCSS").Include(
                      "~/css/lib/bootstrap/bootstrap.min.css",
                      "~/css/lib/owl.carousel.min.css",
                      "~/css/lib/owl.theme.default.min.css",
                      "~/css/helper.css"));

            BundleTable.EnableOptimizations = true;
        }
    }
}
